package com.cliente.escola.gradecurricular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeCurricularApplicationTests {

	@Test
	void contextLoads() {
	}

}
